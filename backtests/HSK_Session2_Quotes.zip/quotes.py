"""python3 quotes.py [--rpc ARCHIVE_RPC_URL]"""
import argparse
import json
import urllib.request
from pathlib import Path
from decimal import Decimal, localcontext

ROOT = Path(__file__).resolve().parent
archive = json.loads((ROOT / 'archive.json').read_text())
state = archive['pool_calls']
Q96 = 2**96
fee = int(state['fee'],16)
unit = 10**6
token0 = '0x'+state['token0'][-40:]
token1 = '0x'+state['token1'][-40:]

def words(data):
    return [int(data[i:i+64],16) for i in range(2,len(data),64)]

def ceildiv(n,d):
    return -(-n//d)

def tick_at(p):
    with localcontext() as c:
        c.prec = 80
        from decimal import ROUND_FLOOR
        return int(((Decimal(p)/Q96).ln()*2/Decimal('1.0001').ln()).to_integral_value(rounding=ROUND_FLOOR))

p = words(state['slot0'])[0]
tick = tick_at(p)
spacing = int(state['tickSpacing'],16)
def within_band(end):
    assert tick_at(end)//spacing == tick//spacing, 'requires adjacent tick data'

# This archived exact-input swap spent 1 USDT. Its start and end prices
# lie strictly inside one tick-spacing interval, giving a single swap step.
control_out, control_end, _, _ = words(state['quote_one_USDT_raw'])
within_band(control_end)
dp = control_end-p
net_input = unit-fee
low = net_input*Q96//(dp+1)+1
high = net_input*Q96//dp
liquidities = [v for v in range(low,high+1)
               if v*Q96*dp//(p*control_end) == control_out]
assert len(liquidities)==1
L = liquidities[0]

def quote(amount, buy):
    numerator = L*Q96
    if buy:  # exact token0 output, round token1 input and fee up
        end = ceildiv(numerator*p,numerator-amount*p)
        net = ceildiv(L*(end-p),Q96)
        result = ceildiv(net*unit,unit-fee)
    else:  # exact token0 input, round token1 output down
        net = amount*(unit-fee)//unit
        end = ceildiv(numerator*p,numerator+net*p)
        result = L*(p-end)//Q96
    within_band(end)
    return result,end

control = archive['sell_control']
assert control['block']==archive['block'] and control['pool']==archive['pool']
assert quote(int(control['raw_WHSK_in']),False)[0] == int(control['raw_USDT_quote_out'])

def rpc(url,method,params):
    body = json.dumps(dict(jsonrpc='2.0',id=1,method=method,params=params)).encode()
    req = urllib.request.Request(url,data=body,headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=15) as r:
        reply = json.load(r)
    if reply.get('error') or reply.get('result') is None:
        raise ValueError(reply.get('error','missing result'))
    return reply['result']

def run(url):
    block = hex(archive['block'])
    if url:
        assert int(rpc(url,'eth_chainId',[]),16) == archive['chain_id']
        assert rpc(url,'eth_getBlockByNumber',[block,False])['hash'] == archive['block_hash']
    rows = []
    for user,size,buy in [('A_full',1000,False),('B_exact_out',600,True),('A_remaining',400,False)]:
        fixed = size*10**18
        cash,end = quote(fixed,buy)
        a,b = (token1,token0) if buy else (token0,token1)
        selector = 'bd21704a' if buy else 'c6a5026a'
        args = [int(a,16),int(b,16),fixed,fee,0]
        payload = {'to':archive['quoter'],'data':'0x'+selector+''.join(f'{x:064x}' for x in args)}
        raw = None
        if url:
            raw = rpc(url,'eth_call',[payload,block])
            assert len(raw)==258 and words(raw)[:2]==[cash,end], 'direct quote mismatch'
        rows.append(dict(id=user,kind='exact_output' if buy else 'exact_input',
            token_in=a,token_out=b,amount_in_raw=str(cash if buy else fixed),
            amount_out_raw=str(fixed if buy else cash),sqrt_price_after_x96=str(end),
            ending_tick=tick_at(end),request={'method':'eth_call','params':[payload,block]},
            direct_response=raw))
    if url:
        assert rpc(url,'eth_getBlockByNumber',[block,False])['hash']==archive['block_hash']
    return dict(chain_id=archive['chain_id'],block=archive['block'],block_hash=archive['block_hash'],
        timestamp_utc=archive['utc'],pool=archive['pool'],factory=archive['factory'],quoter=archive['quoter'],
        pool_fee_pips=fee,token0_whsk_decimals=18,token1_usdt_decimals=6,starting_tick=tick,
        active_liquidity_raw=str(L),evidence_mode='historical_eth_call_verified' if url else 'archived_state_reconstruction',
        order_origin='team_hypothetical_sizes',firm=False,participant_signed_order=None,
        execution_receipt=None,settlement_gas_usdt=None,quotes=rows)

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--rpc',help='archive RPC for optional read-only verification at the original block')
    print(json.dumps(run(parser.parse_args().rpc),indent=2))
