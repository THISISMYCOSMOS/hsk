# 2차 인계 · 같은 블록의 WHSK/USDT 단일 풀 견적 세 건

2026-11-24 23:41:31 KST, HashKey 메인넷(chain ID 177) 블록 30,592,078의 종료 상태를 사용했다. 블록 해시는 0x8e9ec7357cca666d04911b91bb3f5cf0292a7b4e5150a4e6febe30daa1280bda 이다.

| 가상 요청 | 입력 원 단위 | 출력 원 단위 | 사람이 읽는 금액 |
|---|---:|---:|---|
| A 전량 매도 · 정확 입력 | 1000000000000000000000 WHSK raw | 80558131 USDT raw | 1,000 WHSK → 80.558131 USDT |
| B 매수 · 정확 출력 | 48641160 USDT raw | 600000000000000000000 WHSK raw | 48.641160 USDT → 600 WHSK |
| A 잔량 매도 · 정확 입력 | 400000000000000000000 WHSK raw | 32226965 USDT raw | 400 WHSK → 32.226965 USDT |

세 행은 같은 시작 상태에서 각각 평가한 대안이다. 원 단위는 WHSK 10⁻¹⁸개, USDT 10⁻⁶개다. 팀이 지정한 주문 크기로 계산했다. 실제 참가자 주문·서명·확정 RFQ·체결 영수증은 확보되지 않았다. 금액에는 풀 수수료 0.30%와 주문 크기에 따른 가격 영향이 반영되어 있다. UI 최적 경로, 지갑 가스비, 별도 정산·승인비는 미측정이다. 이 단일 풀 기준으로 직접 매칭이 양측에 나눠 줄 수 있는 금액은 추가비 전 48.641160 + 32.226965 − 80.558131 = 0.309994 USDT다.

## 풀과 데이터 출처

- WHSK/USDT 풀 0x4ff515761864e7838b0adb8b5b2b8b7a068905dc
- QuoterV2 0x603f70466fddbe3f238220b9a74fff419a2bbfdd
- Factory 0x972ca9d1662f5e029cd18327d29026532e84c742
- 팀 보관 원본 HSKSwap_mainnet_handoff.zip의 contracts.json에 블록 번호·해시, slot0 및 1 USDT 정확 입력 QuoterV2 응답이 있다. replay.json에는 같은 블록의 WHSK 매도 대조값이 있다. archive.json에 필요한 원문 필드, 원본 링크·SHA-256, 파일별 해시를 보존했다.
- 공식 네트워크 목록 https://docs.hskchain.net/docs/Build-on-HashKey-Chain/network-info 및 Superchain 등록 정보 https://github.com/ethereum-optimism/superchain-registry/blob/main/superchain/configs/mainnet/hashkeychain.toml 를 확인했다. 공식 RPC 및 탐색기 proxy에 세 eth_call을 각각 요청했으며 모두 HTTP 403이었다. 등록된 시퀀서에는 체인 ID 요청 시 HTTP 503이 반환됐다. 경로별 결과는 read_attempts.json에 있다.

## 재현

압축을 푼 폴더에서 Python 3.11 이상의 표준 라이브러리로 실행한다.

```sh
python3 quotes.py
```

결과는 quotes.json과 같다. 1 USDT의 수수료 차감 입력과 Quoter가 반환한 종료 제곱근 가격에서 가능한 유동성 정수 27개를 구했다. WHSK 출력 최소 단위까지 일치하는 유일한 값은 1475813786831558685였다. 같은 상태에서 반대 방향 보관 견적 17.507617360455450541 WHSK → 1.410647 USDT도 일치하는지 검사한다. 시작 틱은 −301482이고 세 주문 모두 틱 간격 60의 동일 구간 안에서 끝난다. 정확 입력 매도의 출력은 내림하며, 정확 출력 매수의 필요 입력과 수수료는 올림한다.

과거 상태 조회를 지원하는 RPC 주소를 HSK_RPC에 설정한 환경에서는 아래 한 줄로 세 QuoterV2 응답의 금액·종료 가격을 대조할 수 있다. 체인 ID와 호출 전후 블록 해시도 확인한다.

```sh
python3 quotes.py --rpc "$HSK_RPC"
```

quotes.json에는 세 호출의 calldata·원 단위 입력 및 출력이 있다. 이번 세션의 direct_response는 모두 null이며 보관 응답과 구분된다.
