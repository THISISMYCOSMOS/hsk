"""Reconcile independent balance snapshots and write B's exchange records."""
import hashlib
import json
from pathlib import Path
from routes import BOOK, ROOT, SCENARIOS, plan


def write_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2)+"\n")


def reconcile(p, e):
    wallets = e["before"]
    delta = {who: {t: str(int(e["after"][who][t])-int(v)) for t,v in bal.items()}
             for who, bal in wallets.items()}
    for t in BOOK["tokens"]:
        assert sum(int(w[t]) for w in delta.values()) == 0
    selected = next(c for c in p["candidates"] if c["route"] == p["route"])
    if e["status"] == "settled":
        assert selected["eligible"] and e["event"]["route"] == p["route_code"]
        sign = 1 if p["side"] == "sell" else -1
        expected = {who: {"WHSK": 0, "USDT": 0} for who in wallets}
        for leg in selected["legs"]:
            other = {"signed_B":"B", "signed_R":"RFQ_maker", "fixed_DEX":"DEX"}[leg["source"]]
            for t,val in (("WHSK", -sign*int(leg["whsk_raw"])), ("USDT", sign*int(leg["usdt_raw"]))):
                expected["A"][t] += val
                expected[other][t] -= val
        fee = int(selected["fee_paid_by_A_raw"])
        expected["A"]["USDT"] -= fee
        expected["fee_collector"]["USDT"] += fee
        assert expected == {k:{t:int(v) for t,v in w.items()} for k,w in delta.items()}
        assert int(delta["A"]["USDT"]) == sign*int(selected["a_net_usdt_raw"])
    else:
        assert p["route"] == "no_fill" or e["revert_reason"] == "residual quote"
        assert e["event"] is None and e["filled_A_raw"] == e["filled_other_raw"] == "0"
        assert e["after"] == e["before"]
    return delta


def records():
    paths = ["routes.py","src/SessionSettlement.sol","test/Fixture.sol","test/Session.t.sol","fixtures/book.json"]
    version = hashlib.sha256(b"".join((ROOT/p).read_bytes() for p in paths)).hexdigest()
    for name, config in SCENARIOS.items():
        p = plan(name, **config)
        assert p == json.loads((ROOT/f"fixtures/plans/{name}.json").read_text())
        e = json.loads((ROOT/f"handoff/evm_{name}.json").read_text())
        delta = reconcile(p,e)
        key = p["order_id"]
        quotes = []
        for source, quantity, cash, firm, available, deadline in [
            ("DEX_full",p["amount_raw"],p["full_raw"],False,True,BOOK["expiry"]),
            ("DEX_rest",str(int(p["amount_raw"])-int(p["lot_raw"])),p["residual_raw"],False,True,BOOK["expiry"]),
            ("B_signed_limit",p["capacity_raw"],p["other_limit_raw"],True,p["opposite"],BOOK["expiry"]),
            ("RFQ_all",p["amount_raw"],p["rfq_raw"],True,p["rfq_status"]!="absent",
             "2026-11-26T03:59:59Z" if p["rfq_status"]=="expired" else BOOK["expiry"])]:
            quotes.append(dict(quote_id=f"{key}/{source}",source=source,firm=firm and available,
                registered=available,available_qty_raw=quantity if available else "0",
                cash_raw=cash if available else None,expires_at_utc=deadline if available else None,
                quote_origin="팀 시연 주문" if firm else "가상 호가",block_number=100))
        yield {k:BOOK[k] for k in ("schema_version","run_id","chain_id","block_number","block_hash",
            "block_hash_reason","observed_at_utc","available_at_utc","expiry","objective","source","evidence_mode")} | {
            "code_version_sha256":version,"order_id":key,"received_at_utc":BOOK["available_at_utc"],
            "clock_basis":"fixed fixture UTC","submitted_at_utc":None,"included_at_utc":None,"confirmed_at_utc":None,
            "tx_hash":None,"receipt_status":None,"gas_used_raw":None,"gas_paid_hsk_raw":None,
            "null_reason":"in-process Foundry EVM call; no broadcast, mined receipt or block inclusion delay",
            "retry_of":None,"tokens":{"WHSK":{"address":e["hsk_address"],"decimals":18},
                                      "USDT":{"address":e["usdt_address"],"decimals":6}},
            "quote_book":quotes,"decision":p,"execution":e,"wallet_delta_raw":delta,
            "actual_service_fee_usdt_raw":delta["fee_collector"]["USDT"],
            "risk_signal":{"model_version":None,"feature_cutoff":BOOK["available_at_utc"],
                "target":"route survives inclusion delay with positive net savings","horizon":None,
                "prediction":None,"sample_count":0,"validation":None,"recommendation":None,
                "abstain_reason":p["abstain_reason"]}}


def main():
    rows=list(records())
    (ROOT/"handoff/ledger.jsonl").write_text("".join(json.dumps(r,ensure_ascii=False)+"\n" for r in rows))
    write_json(ROOT/"handoff/first_order.json", rows[0])
    print(f"{len(rows)} scenario decisions reconciled against local EVM balances")


if __name__=="__main__":
    main()
