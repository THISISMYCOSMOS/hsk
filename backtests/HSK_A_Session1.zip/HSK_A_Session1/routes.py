"""Fixed-book candidate enumeration. All monetary calculations use token integers."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BOOK = json.loads((ROOT / "fixtures/book.json").read_text())
SCENARIOS = {
    "direct": {},
    "no_opposite": {"opposite": False},
    "rfq_wins": {"rfq": "live"},
    "rfq_expired": {"rfq": "expired"},
    "too_costly": {"fee": 11_000_000},
    "no_gain": {"fee": 10_000_000},
    "same_side": {"same_side": True},
    "maker_limit": {"other_limit": 598_000_000},
    "residual_revert": {"actual_rest": 396_000_000},
    "no_fill": {"limit": 1_002_000_000},
    "buy_direct": {"side": "buy"},
    "buy_rfq": {"side": "buy", "rfq": "live"},
    "buy_residual_revert": {"side": "buy", "actual_rest": 404_000_000},
    "maker_partial": {"capacity": 1000 * 10**18, "maker_partial": True},
    "maker_all_or_none": {"capacity": 1000 * 10**18, "maker_partial": False},
}
CODES = {"no_fill": 0, "dex": 1, "direct+dex": 2, "rfq": 3}


def plan(name, *, side="sell", kind=None, opposite=True, rfq="absent", same_side=False,
         fee=None, limit=None, actual_rest=None, maker_partial=False, capacity=None,
         other_limit=None, taker_partial=False):
    if side not in ("sell", "buy") or kind not in (None, BOOK[side]["kind"]):
        raise ValueError("지원 조합은 WHSK 매도 exact_in, WHSK 매수 exact_out")
    terms = BOOK[side]
    sell = side == "sell"
    sign = 1 if sell else -1
    total = int(BOOK["amount_raw"])
    lot = int(BOOK["opposite_lot_raw"])
    capacity = int(BOOK["opposite_capacity_raw"]) if capacity is None else capacity
    baseline, residual, other, firm = [int(terms[k]) for k in
        ("dex_full_raw", "dex_rest_raw", "other_baseline_raw", "rfq_raw")]
    limit = int(terms["limit_raw"]) if limit is None else limit
    other_limit = int(terms["other_limit_raw"]) * capacity // lot if other_limit is None else other_limit
    fee = int(BOOK["fee_raw"]) if fee is None else fee
    if min(fee, limit, other_limit, capacity) < 0:
        raise ValueError("음수 입력")
    candidates = []

    def leg(source, qty, cash):
        return dict(source=source, whsk_raw=str(qty), usdt_raw=str(cash))

    def add(route, a, b, legs, reason=None):
        a_gain = sign * (a - baseline) if a is not None else None
        b_gain = sign * (other - b) if b is not None else None
        if reason is None and a is not None and sign * (a - limit) < 0:
            reason = "A_signed_limit"
        if reason is None and a_gain is not None and min(a_gain, b_gain or 0) < 0:
            reason = "participant_worse_than_baseline"
        candidates.append(dict(route=route, eligible=reason is None, exclusion=reason,
            legs=legs, a_benchmark_raw=str(baseline),
            b_benchmark_raw=str(other) if b is not None else None,
            a_net_usdt_raw=None if a is None else str(a),
            b_usdt_raw=None if b is None else str(b),
            a_gain_raw=None if a_gain is None else str(a_gain),
            b_gain_raw=None if b_gain is None else str(b_gain),
            total_gain_raw=None if a_gain is None else str(a_gain + (b_gain or 0)),
            fee_paid_by_A_raw=str(fee if route == "direct+dex" else 0)))

    add("dex", baseline, None, [leg("fixed_DEX", total, baseline)])
    surplus = sign * (other + residual - baseline) - fee
    # Allocate any odd micro-USDT to B. The limit checks use exact integers.
    payment = baseline - residual + sign * (fee + surplus // 2)
    reason = None
    if not opposite:
        reason = "absent"
    elif same_side:
        reason = "same_side"
    elif capacity < lot or (capacity != lot and not maker_partial):
        reason = "maker_quantity_constraint"
    elif surplus < 0:
        reason = "cost_exceeds_surplus"
    elif sign * (other_limit * lot - payment * capacity) < 0:
        reason = "B_signed_limit"
    add("direct+dex", payment + residual - sign * fee, payment,
        [leg("signed_B", lot, payment), leg("fixed_DEX", total-lot, residual)], reason)
    add("rfq", firm, None, [leg("signed_R", total, firm)],
        None if rfq == "live" else "rfq_" + rfq)
    add("no_fill", None, None, [])
    valid = [c for c in candidates if c["eligible"] and c["route"] != "no_fill"]
    def rank(c):
        return int(c["total_gain_raw"]), int(c["a_gain_raw"]), -CODES[c["route"]]
    choice = max(valid, key=rank)["route"] if valid else "no_fill"
    a_best = max(valid, key=lambda c: (int(c["a_gain_raw"]), rank(c)))["route"] if valid else "no_fill"
    return dict(order_id="S1-"+name, side=side, kind=terms["kind"], partial_allowed=taker_partial,
        amount_raw=str(total), limit_raw=str(limit), fee_raw=str(fee), capacity_raw=str(capacity),
        maker_partial=maker_partial, other_limit_raw=str(other_limit), payment_raw=str(payment),
        full_raw=str(baseline), residual_raw=str(residual),
        actual_rest_raw=str(residual if actual_rest is None else actual_rest), rfq_raw=str(firm),
        lot_raw=str(lot), reference_other_raw=str(other), rfq_status=rfq, opposite=opposite,
        same_side=same_side, route=choice, route_code=CODES[choice], best_for_A=a_best,
        greedy_direct_first=next((r for r in ("direct+dex","dex","rfq") if any(
            c["route"] == r and c["eligible"] for c in valid)), "no_fill"),
        candidates=candidates, rule_selection=choice, ai_selection=None,
        model_version=None, abstain_reason="B latency model and validation samples unavailable",
        lp_used_raw="0", lp_exclusion="no committed LP capital or bilateral valuation",
        gas_estimate_raw=None, gas_conversion_usdt=None,
        gas_reason="No RPC gas estimate or HSK/USDT rate for synthetic fixture",
        costs_basis="DEX net quote; signed service fee in USDT only on direct+dex")


def generate():
    directory = ROOT / "fixtures" / "plans"
    directory.mkdir(exist_ok=True)
    for name, config in SCENARIOS.items():
        (directory / (name+".json")).write_text(
            json.dumps(plan(name, **config), indent=2, ensure_ascii=False) + "\n")


if __name__ == "__main__":
    generate()
