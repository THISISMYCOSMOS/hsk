// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

interface IToken {
    function transferFrom(address from, address to, uint256 amount) external returns (bool);
}
interface IBook {
    function quote(bool sell, uint256 whsk) external view returns (uint256 usdt);
}

// Session-one harness: the funded local book stands in for an external router.
// No deployment configuration or mainnet adapter is provided.
contract SessionSettlement {
    struct Order {
        address owner;
        address recipient;
        address counterparty; // optional binding for a firm RFQ
        bool sell;
        uint256 quantity;     // WHSK, always fixed side of the quantity constraint
        uint256 limit;        // USDT minimum proceeds / maximum spend
        uint256 maxFee;       // USDT, included in limit
        bool partialAllowed;
        uint256 deadline;
        uint256 nonce;
    }
    struct Path {
        uint8 route;          // 1 book, 2 signed opposite + book, 3 all-or-none RFQ
        uint256 directSize;
        uint256 payment;
        uint256 bookLimit;    // signed aggregate limit also enforced independently
        uint256 fee;
    }
    IToken public immutable whsk;
    IToken public immutable usdt;
    IBook public immutable book;
    address public immutable executor;
    address public immutable collector;
    bool public paused;
    bytes32 constant DOMAIN = keccak256("EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)");
    bytes32 constant TYPE = keccak256("Order(address owner,address recipient,address counterparty,address whsk,address usdt,bool sell,uint256 quantity,uint256 limit,uint256 maxFee,bool partialAllowed,uint256 deadline,uint256 nonce)");
    mapping(bytes32 => uint256) public filled;
    mapping(address => mapping(uint256 => bool)) public cancelled;
    mapping(address => mapping(uint256 => bytes32)) public nonceOrder;
    event Settled(bytes32 indexed orderId, bytes32 indexed oppositeId, uint8 route,
        uint256 whskQuantity, uint256 directQuantity, uint256 directPayment, uint256 bookUSDT, uint256 fee);
    event Cancelled(address indexed owner, uint256 nonce);

    constructor(IToken w, IToken u, IBook b, address e, address c) {
        whsk=w; usdt=u; book=b; executor=e; collector=c;
    }
    function setPaused(bool state) external { require(msg.sender==executor, "executor"); paused=state; }
    function cancel(uint256 nonce) external { cancelled[msg.sender][nonce]=true; emit Cancelled(msg.sender, nonce); }
    function digest(Order memory o) public view returns (bytes32) {
        bytes32 domain = keccak256(abi.encode(DOMAIN, keccak256("HSK session fixture"), keccak256("1"), block.chainid, address(this)));
        bytes32 data = keccak256(abi.encode(TYPE,o.owner,o.recipient,o.counterparty,address(whsk),address(usdt),
            o.sell,o.quantity,o.limit,o.maxFee,o.partialAllowed,o.deadline,o.nonce));
        return keccak256(abi.encodePacked(hex"1901",domain,data));
    }
    function consume(Order memory o, bytes calldata sig, uint256 qty) private returns (bytes32 h) {
        require(o.owner!=address(0) && o.recipient!=address(0) && sig.length==65, "identity");
        require(block.timestamp<=o.deadline, "expired");
        require(!cancelled[o.owner][o.nonce], "cancelled");
        h=digest(o);
        bytes32 previous=nonceOrder[o.owner][o.nonce];
        require(previous==bytes32(0) || previous==h, "nonce conflict");
        bytes32 r=bytes32(sig[:32]);
        bytes32 s=bytes32(sig[32:64]);
        uint8 v=uint8(sig[64]);
        require(uint256(s)<=0x7fffffffffffffffffffffffffffffff5d576e7357a4501ddfe92f46681b20a0
            && (v==27 || v==28) && ecrecover(h,v,r,s)==o.owner, "signature");
        nonceOrder[o.owner][o.nonce]=h;
        require(qty>0 && (o.partialAllowed || qty==o.quantity), "partial");
        filled[h]+=qty;
        require(filled[h]<=o.quantity, "spent");
    }
    function bounds(Order memory o, uint256 qty, uint256 cash) private pure {
        if(o.sell) require(cash*o.quantity>=o.limit*qty, "min proceeds");
        else require(cash*o.quantity<=o.limit*qty, "max spend");
    }
    function move(IToken token, address from, address to, uint256 value) private {
        require(token.transferFrom(from,to,value), "transfer");
    }
    function settle(Order calldata a, bytes calldata sa, Order calldata b, bytes calldata sb, Path calldata p) external {
        require(msg.sender==executor && !paused, "inactive");
        require(a.counterparty==address(0), "taker policy");
        require(p.route>=1 && p.route<=3 && p.fee<=a.maxFee, "plan");
        bytes32 h=consume(a,sa,a.quantity);
        bytes32 other;
        if(p.route==1) require(p.directSize==0 && p.payment==0 && p.fee==0, "book only");
        else {
            require(b.owner!=a.owner && a.sell!=b.sell, "opposite");
            require(b.counterparty==address(0) || b.counterparty==a.owner, "recipient binding");
            if(p.route==3) require(!b.partialAllowed && p.directSize==a.quantity && p.fee==0
                && p.payment==b.limit, "firm quote");
            else require(p.directSize<a.quantity, "split");
            other=consume(b,sb,p.directSize);
            bounds(b,p.directSize,p.payment);
            move(whsk, a.sell?a.owner:b.owner, a.sell?b.recipient:a.recipient,p.directSize);
            move(usdt, a.sell?b.owner:a.owner, a.sell?a.recipient:b.recipient,p.payment);
        }
        uint256 rest=a.quantity-p.directSize;
        uint256 cash;
        if(rest!=0) {
            cash=book.quote(a.sell,rest);
            require(a.sell ? cash>=p.bookLimit : cash<=p.bookLimit, "residual quote");
            move(whsk,a.sell?a.owner:address(book),a.sell?address(book):a.recipient,rest);
            move(usdt,a.sell?address(book):a.owner,a.sell?a.recipient:address(book),cash);
        }
        uint256 gross=cash+p.payment;
        if(p.fee!=0) move(usdt,a.owner,collector,p.fee);
        bounds(a,a.quantity,a.sell ? gross-p.fee : gross+p.fee);
        emit Settled(h,other,p.route,a.quantity,p.directSize,p.payment,cash,p.fee);
    }
}
