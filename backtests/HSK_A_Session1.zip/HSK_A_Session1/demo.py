"""Build an offline, dependency-free viewer for the reconciled evidence."""
from decimal import Decimal
from html import escape
import argparse
import json
from routes import ROOT, SCENARIOS, plan

NAMES = ["직접 600 + DEX 400","반대 주문 없음","전량 RFQ 우세","RFQ 기한 만료","추가 비용 11","추가 비용 10",
         "같은 방향 주문","B의 최대 지불액 초과","잔량 매도 실패","A 최소 수령액 미달","매수 · 직접 경로",
         "매수 · 전량 RFQ","잔량 매수 실패","B 부분 체결 허용","B 전량 조건"]
LABEL = {"dex":"전량 DEX","direct+dex":"직접 + 잔량 DEX","rfq":"전량 RFQ","no_fill":"미체결",
         "settled":"정산 완료","reverted":"전체 원복","not_submitted":"제출 보류"}
REASON = {"absent":"반대 주문 없음","rfq_absent":"RFQ 없음","rfq_expired":"RFQ 만료",
    "maker_quantity_constraint":"반대 주문 수량 조건","same_side":"두 주문 방향 동일",
    "B_signed_limit":"B 한도 초과","A_signed_limit":"A 한도 초과","cost_exceeds_surplus":"추가 비용이 절감 초과",
    "participant_worse_than_baseline":"참여자 순액 악화","residual quote":"잔량 견적 한도 위반"}

def fmt(value, decimals=6):
    if value is None:
        return "—"
    return format(Decimal(value).scaleb(-decimals).normalize(),",f")

def table(headers, rows):
    return "<div class='scroll'><table><thead><tr>"+"".join("<th>"+escape(h)+"</th>" for h in headers)+"</tr></thead><tbody>"+"".join("<tr>"+"".join("<td>"+escape(str(v))+"</td>" for v in row)+"</tr>" for row in rows)+"</tbody></table></div>"

def section(row, index):
    p,e=row["decision"],row["execution"]
    verb="순수령" if p["side"]=="sell" else "총지출"
    name="매도" if p["side"]=="sell" else "매수"
    actual=abs(int(row["wallet_delta_raw"]["A"]["USDT"]))
    candidates=[]
    for c in p["candidates"]:
        show=c["eligible"] or c["exclusion"] not in ("rfq_absent","absent")
        state=REASON.get(c["exclusion"],c["exclusion"]) or ("선택" if c["route"]==p["route"] else "대기" if c["route"]=="no_fill" else "유효")
        candidates.append([LABEL[c["route"]],state,*[fmt(c[k]) if show else "—" for k in ("a_net_usdt_raw","b_usdt_raw","total_gain_raw")]])
    wallet_rows=[]
    for who in e["before"]:
        for t, dec in (("WHSK",18),("USDT",6)):
            wallet_rows.append([who,t,fmt(e["before"][who][t],dec),fmt(e["after"][who][t],dec),fmt(row["wallet_delta_raw"][who][t],dec)])
    note={"direct+dex":"B의 견적은 600 WHSK에만 적용된다. 남은 400 WHSK는 DEX의 잔량 견적으로 계산한다.",
          "dex":"유효한 대안의 순절감과 서명 한도를 비교해 전량 DEX를 선택했다.",
          "no_fill":"서명한 금액 한도를 충족하는 후보가 없어 제출을 보류했다.",
          "rfq":"전량 RFQ는 주문 전체에 한 번만 적용된다. 직접 매칭과 동시에 사용할 수 없다."}[p["route"]]
    if e["status"]=="reverted":
        note+=f' 잔량 견적이 {fmt(p["residual_raw"])}에서 {fmt(p["actual_rest_raw"])} USDT로 변해 전체 교환이 원복됐다.'
    cards=[("기존 전량 DEX",fmt(p["full_raw"])+" USDT"),("선택 경로",LABEL[p["route"]]),
           ("정산 후 A "+verb,fmt(actual)+" USDT"),("정산 결과",LABEL[e["status"]])]
    return f'<section id="s{index}" '+("hidden" if index else "")+f'><p class="meta">{p["order_id"]} · 고정 견적 2026-11-26 04:00 UTC</p><h2>1,000 WHSK {name}</h2><div class="cards">'+''.join(f'<div><small>{k}</small><b>{v}</b></div>' for k,v in cards)+'</div><h3>같은 주문의 후보별 견적</h3>'+table(["후보","판정","A "+verb+" (USDT)","B 거래액 (USDT)","참여자 절감 합 (USDT)"],candidates)+f'<p>{note}</p><h3>정산 전후 지갑 잔고</h3>'+table(["지갑","자산","정산 전","정산 후","증감"],wallet_rows)+'<p class="meta">WHSK와 USDT는 모의 토큰. 투자 손익·네이티브 가스·AI 예측값은 미측정. 직접 경로의 합의 비용만 USDT로 차감.</p></section>'

def build():
    rows=[json.loads(line) for line in (ROOT/"handoff/ledger.jsonl").read_text().splitlines()]
    assert len(NAMES)==len(rows)
    doc='''<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>HSK 주문 정산 검산</title><style>
*{box-sizing:border-box} body{margin:0;background:#f4f6f5;color:#142723;font:16px/1.55 'Inter',system-ui,sans-serif} main{max-width:960px;margin:auto;padding:38px 20px}
h1{margin:0} h2{font-size:30px;margin:4px 0 16px}h3{margin-top:28px}.meta,small{color:#49605a}label{display:block;margin:24px 0 6px}
select{font:inherit;background:white;padding:8px 14px;border:1px solid #aabbb5;border-radius:5px;min-width:240px}
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px}.cards div{padding:14px;background:#e0eee8;border-radius:6px}.cards b,.cards small{display:block}
.scroll{overflow-x:auto} table{border-collapse:collapse;width:100%;background:#fff;font-variant-numeric:tabular-nums}td,th{text-align:right;border-bottom:1px solid #d8e1dd;padding:7px 10px;white-space:nowrap}
td:first-child,th:first-child{text-align:left}th{color:#36594e;background:#e8efec;font-size:.88em}section{margin-top:18px}</style><main>
<h1>HSK 주문 정산 검산</h1><p>로컬 EVM에 기록된 15개 주문 시나리오</p><label for="case">주문 사례</label><select id="case">'''
    doc+=''.join(f'<option value="s{i}">{escape(s)}</option>' for i,s in enumerate(NAMES))+'</select>'
    doc+=''.join(section(r,i) for i,r in enumerate(rows))
    doc+='</main><script>document.querySelector("select").onchange=e=>document.querySelectorAll("section").forEach(s=>s.hidden=s.id!==e.target.value)</script></html>'
    (ROOT/"DEMO.html").write_text(doc)

if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("scenario",choices=["build",*SCENARIOS])
    parser.add_argument("--kind",choices=["exact_in","exact_out"])
    args=parser.parse_args()
    if args.scenario=="build":
        build()
    else:
        try: result=plan(args.scenario,kind=args.kind,**SCENARIOS[args.scenario])
        except ValueError as err: parser.error(str(err))
        print(json.dumps(result,indent=2,ensure_ascii=False))
