import unittest
from routes import plan

class Routing(unittest.TestCase):
    def chosen(self,p):
        return next(c for c in p["candidates"] if c["route"]==p["route"])
    def test_common_order(self):
        c=self.chosen(plan("sell"))
        self.assertEqual([c[k] for k in ("a_net_usdt_raw","b_usdt_raw","a_gain_raw","b_gain_raw")],
                         ["994000000","599000000","4000000","4000000"])
    def test_rfq_beats_greedy(self):
        p=plan("rfq",rfq="live")
        self.assertEqual((p["route"],p["greedy_direct_first"]),("rfq","direct+dex"))
        self.assertEqual(self.chosen(p)["total_gain_raw"],"11000000")
    def test_odd_micro(self):
        c=self.chosen(plan("round",fee=2_000_001))
        self.assertEqual((c["a_gain_raw"],c["b_gain_raw"]),("3999999","4000000"))
    def test_partial_buy_signed_max(self):
        p=plan("partial",side="buy",capacity=1000*10**18,maker_partial=True)
        self.assertEqual(p["route"],"direct+dex")
    def test_unsupported(self):
        for side,kind in [("sell","exact_out"),("buy","exact_in"),("swap","exact_in")]:
            with self.assertRaisesRegex(ValueError,"지원 조합"): plan("invalid",side=side,kind=kind)
    def test_buy(self):
        c=self.chosen(plan("buy",side="buy"))
        self.assertEqual((c["a_net_usdt_raw"],c["b_usdt_raw"]),("1006000000","601000000"))
    def test_balance_limit(self):
        self.assertEqual(plan("maker",other_limit=598_000_000)["route"],"dex")
    def test_unfilled(self):
        self.assertEqual(plan("reject",limit=1_002_000_000,rfq="live")["route"],"no_fill")

if __name__=="__main__": unittest.main()
