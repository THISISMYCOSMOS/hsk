#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 routes.py
python3 -m unittest -v test_routes
args=(test --offline --color never)
if [[ -n "${SOLC_BIN:-}" ]]; then args+=(--use "$SOLC_BIN"); fi
"${FORGE_BIN:-forge}" "${args[@]}" | tee handoff/forge_tests.txt
python3 handoff.py
python3 demo.py build
