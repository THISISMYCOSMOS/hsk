"""Run with Python 3 in the extracted folder. Values measured in pre-swap USDT."""
import csv
import math
from collections import Counter
from pathlib import Path
from statistics import median

root = Path(__file__).resolve().parent
rows = [r for r in csv.DictReader((root/'swaps.csv').open()) if r['base']=='WHSK']
results = []
for prev, row in zip(rows, rows[1:]):
    # Ex-post quality filter: keep same-band events that reproduce the receipt.
    band = int(prev['tick_after'])//60*60
    if int(row['tick_after'])//60*60 != band or prev['active_liquidity_after'] != row['active_liquidity_after']:
        continue
    sqrt = int(prev['sqrt_price_x96_after'])/2**96
    spot = sqrt**2*1e12
    L = int(prev['active_liquidity_after'])
    depth = L*sqrt/1e6
    sell = int(row['amount0_raw'])>0
    size = float(row['pool_delta_base'])*spot if sell else float(row['pool_delta_USDT'])
    received = -float(row['pool_delta_USDT']) if sell else -float(row['pool_delta_base'])*spot
    def pool(value, multiplier):
        net = value*0.997
        return net/(1+net/(depth*multiplier))
    if abs(pool(size,1)-received)>0.0000011:
        continue
    direct = min(size,50)
    # A hypothetical maker quotes pre-swap spot with a 10bp haircut to taker output.
    # RFQ is all-or-none. Fixed costs are incremental vs standalone pool.
    for cost in (0,0.01,0.05):
        for scenario in ('observed','LP','direct','RFQ','all'):
            choices = {'pool':pool(size,1)}
            if scenario in ('direct','all'):
                choices['direct' if direct==size else 'direct+pool']=direct*.999+pool(size-direct,1)-cost
            if scenario in ('RFQ','all'):
                choices['RFQ']=size*.9985-cost
            if scenario in ('LP','all'):
                for matched in ([0,direct] if scenario=='all' else [0]):
                    rest=size-matched
                    if rest<=0: continue
                    # Model fee and incremental inventory of an LP adding L, no protocol fee.
                    # 50bp adverse shock to acquired WHSK on sells; on buys LP sells WHSK:
                    # opportunity risk of a 50bp rebound on disposed inventory, valued at pre-price.
                    risk_base = rest/2 if sell else pool(rest,2)/2
                    lp_profit_stress = rest*.003/2-risk_base*.005
                    if lp_profit_stress < 0: continue
                    choices['direct+LP' if matched else 'LP']=matched*.999+pool(rest,2)-cost
            winner=max(choices,key=choices.get)
            results.append(dict(block=row['block'],tx=row['tx_hash'],side='sell' if sell else 'buy',
                size=size,baseline=received,scenario=scenario,cost=cost,winner=winner,
                gain=choices[winner]-choices['pool'],raw_LP_gain=pool(size,2)-pool(size,1)))
with (root/'results.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=results[0]);w.writeheader();w.writerows(results)
for cost in (0,.01,.05):
    for scenario in ('observed','LP','direct','RFQ','all'):
        s=[a for a in results if a['cost']==cost and a['scenario']==scenario]
        print(cost,scenario,len(s),Counter(a['winner'] for a in s),round(sum(a['gain'] for a in s),6))
s=[a for a in results if a['cost']==.01 and a['scenario']=='all']
print('sides',Counter(a['side'] for a in s),'notional',sum(a['size'] for a in s),'gross LP',sum(a['raw_LP_gain'] for a in s),max(a['raw_LP_gain'] for a in s))
for route in sorted(set(a['winner'] for a in s)):
    a=next(a for a in s if a['winner']==route)
    print(route,a)
# Hypothetical maker availability, drawn independently of route performance.
import hashlib
def available(tx, leg, rate):
    v=int.from_bytes(hashlib.sha256((tx+leg).encode()).digest()[:8],'big')/2**64
    return v<rate
lookup={(a['tx'],a['scenario']):a for a in results if a['cost']==.01}
for rate in (.1,.25,.5):
    gains=[]
    for a in s:
        tx=a['tx']
        candidates=[0]
        for leg in ('direct','RFQ'):
            if available(tx,leg,rate): candidates.append(lookup[tx,leg]['gain'])
        gains.append(max(candidates))
    print('availability',rate,sum(x>0 for x in gains),round(sum(gains),6))
