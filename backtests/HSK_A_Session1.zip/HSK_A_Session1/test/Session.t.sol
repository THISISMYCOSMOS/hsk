// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;
import "./Fixture.sol";

contract SessionTest {
    Vm constant vm=Vm(address(uint160(uint256(keccak256("hevm cheat code")))));
    Token w;
    Token u;
    FixedBook book;
    SessionSettlement sut;
    address A;
    address B;
    address R;
    address constant F=address(0xFEE);
    struct Case {
        string json;
        bool sell;
        SessionSettlement.Order a;
        SessionSettlement.Order b;
        SessionSettlement.Path path;
        bytes sa;
        bytes sb;
        bytes makerSignature;
        bytes rfqSignature;
        bytes32 makerDigest;
        bytes32 rfqDigest;
    }
    function setUp() public {
        vm.chainId(31337); vm.roll(100); vm.warp(1795665600);
        A=vm.addr(101); B=vm.addr(102); R=vm.addr(103); // public test actors only
        w=new Token(18); u=new Token(6); book=new FixedBook();
        sut=new SessionSettlement(w,u,book,address(this),F);
        address[4] memory actors=[A,B,R,address(book)];
        for(uint256 i=0;i<actors.length;i++){
            w.mint(actors[i],2000 ether); u.mint(actors[i],2000e6);
            vm.prank(actors[i]); w.approve(address(sut),type(uint256).max);
            vm.prank(actors[i]); u.approve(address(sut),type(uint256).max);
        }
    }
    function num(string memory j,string memory k) private pure returns(uint256){
        return vm.parseUint(vm.parseJsonString(j,k));
    }
    function sign(uint256 key,SessionSettlement.Order memory o) private returns(bytes memory){
        (uint8 v,bytes32 r,bytes32 s)=vm.sign(key,sut.digest(o));
        return abi.encodePacked(r,s,v);
    }
    function load(string memory name) private returns(Case memory c){
        string memory j=vm.readFile(string.concat("fixtures/plans/",name,".json"));
        c.json=j; c.sell=keccak256(bytes(vm.parseJsonString(j,".side")))==keccak256("sell");
        uint8 route=uint8(vm.parseJsonUint(j,".route_code"));
        uint256 qty=num(j,".amount_raw"); uint256 lot=num(j,".lot_raw");
        c.a=SessionSettlement.Order(A,A,address(0),c.sell,qty,num(j,".limit_raw"),num(j,".fee_raw"),
            vm.parseJsonBool(j,".partial_allowed"),block.timestamp+300,1);
        bool firm=route==3;
        SessionSettlement.Order memory maker=SessionSettlement.Order(B,B,address(0),!c.sell,num(j,".capacity_raw"),
            num(j,".other_limit_raw"),0,vm.parseJsonBool(j,".maker_partial"),block.timestamp+300,2);
        if(vm.parseJsonBool(j,".same_side")) maker.sell=c.sell;
        bytes32 rfqState=keccak256(bytes(vm.parseJsonString(j,".rfq_status")));
        SessionSettlement.Order memory rfq=SessionSettlement.Order(R,R,A,!c.sell,qty,num(j,".rfq_raw"),0,false,
            rfqState==keccak256("expired")?block.timestamp-1:block.timestamp+300,3);
        c.makerDigest=sut.digest(maker); c.rfqDigest=sut.digest(rfq);
        if(vm.parseJsonBool(j,".opposite")) c.makerSignature=sign(102,maker);
        if(rfqState!=keccak256("absent")) c.rfqSignature=sign(103,rfq);
        c.b=firm?rfq:maker;
        c.sb=firm?c.rfqSignature:c.makerSignature;
        c.sa=sign(101,c.a);
        c.path=SessionSettlement.Path(route,firm?qty:route==2?lot:0,
            firm?num(j,".rfq_raw"):route==2?num(j,".payment_raw"):0,
            route==2?num(j,".residual_raw"):num(j,".full_raw"),route==2?num(j,".fee_raw"):0);
        book.set(c.sell,qty,num(j,".full_raw"));
        book.set(c.sell,qty-lot,num(j,".actual_rest_raw"));
    }
    function invoke(Case memory c) private returns(bool ok,bytes memory reason){
        return address(sut).call(abi.encodeCall(sut.settle,(c.a,c.sa,c.b,c.sb,c.path)));
    }
    function pair(address who) private view returns(string memory){
        return string.concat('{"WHSK":"',vm.toString(w.balanceOf(who)),'","USDT":"',vm.toString(u.balanceOf(who)),'"}');
    }
    function wallets() private view returns(string memory){
        return string.concat('{"A":',pair(A),',"B":',pair(B),',"RFQ_maker":',pair(R),',"DEX":',pair(address(book)),',"fee_collector":',pair(F),'}');
    }
    function n(uint256 x) private pure returns(string memory){ return vm.toString(x); }
    function executeCase(string memory name,bool expectRevert) private {
        Case memory c=load(name);
        string memory beforeState=wallets();
        uint256 beforeA=u.balanceOf(A);
        uint256 beforeB=u.balanceOf(B);
        uint256 beforeW=w.balanceOf(A);
        bytes32 ha=sut.digest(c.a); bytes32 hb=sut.digest(c.b);
        vm.recordLogs();
        bool submitted=c.path.route!=0;
        bool ok; bytes memory reason;
        if(submitted) (ok,reason)=invoke(c);
        Vm.Log[] memory logs=vm.getRecordedLogs();
        string memory observedEvent="null";
        if(submitted && !expectRevert){
            require(ok,"unexpected rejection");
            require(logs.length==1 && logs[0].emitter==address(sut) && logs[0].topics[1]==ha,"missing event");
            (uint8 route,uint256 q,uint256 d,uint256 pay,uint256 cash,uint256 fee)=abi.decode(logs[0].data,(uint8,uint256,uint256,uint256,uint256,uint256));
            require(q==c.a.quantity && d==c.path.directSize && pay==c.path.payment && fee==c.path.fee && route==c.path.route,"event data");
            require(sut.filled(ha)==q && sut.filled(hb)==d,"fill");
            uint256 net=c.sell?pay+cash-fee:pay+cash+fee;
            require(c.sell?u.balanceOf(A)==beforeA+net:u.balanceOf(A)+net==beforeA,"A cash");
            require(c.sell?w.balanceOf(A)+q==beforeW:w.balanceOf(A)==beforeW+q,"A quantity");
            if(route==2) require(c.sell?u.balanceOf(B)+pay==beforeB:u.balanceOf(B)==beforeB+pay,"B cash");
            observedEvent=string.concat('{"route":',n(route),',"whsk_raw":"',n(q),'","direct_whsk_raw":"',n(d),'","direct_usdt_raw":"',n(pay),'","book_usdt_raw":"',n(cash),'","fee_raw":"',n(fee),'"}');
        } else {
            require(!ok && sut.filled(ha)==0 && sut.filled(hb)==0,"fill changed");
            require(keccak256(bytes(beforeState))==keccak256(bytes(wallets())),"balance changed");
            if(expectRevert) require(keccak256(reason)==keccak256(abi.encodeWithSignature("Error(string)","residual quote")),"wrong revert");
        }
        string memory info=string.concat('{"chain_id":31337,"block_number":100,"hsk_address":"',vm.toString(address(w)),'","usdt_address":"',vm.toString(address(u)),'","settlement":"',vm.toString(address(sut)),'","order_digest":"',vm.toString(ha),'","counter_digest":"',vm.toString(hb),'"');
        string memory outcome=string.concat(',"status":"',ok?"settled":submitted?"reverted":"not_submitted",'","revert_reason":',expectRevert?'"residual quote"':"null",',"event":',observedEvent,',"filled_A_raw":"',n(sut.filled(ha)),'","filled_other_raw":"',n(sut.filled(hb)),'"');
        string memory signatures=string.concat(',"A_signature":"',vm.toString(c.sa),'","B_signature":"',vm.toString(c.makerSignature),'","R_signature":"',vm.toString(c.rfqSignature),'","B_digest":"',vm.toString(c.makerDigest),'","R_digest":"',vm.toString(c.rfqDigest),'"');
        string memory actors=string.concat(',"addresses":{"A":"',vm.toString(A),'","B":"',vm.toString(B),'","RFQ_maker":"',vm.toString(R),'","DEX":"',vm.toString(address(book)),'","fee_collector":"',vm.toString(F),'"}');
        vm.writeFile(string.concat("handoff/evm_",name,".json"),string.concat(info,actors,signatures,outcome,',"before":',beforeState,',"after":',wallets(),'}'));
    }
    function testDirect() public { executeCase("direct",false); }
    function testNoOpposite() public { executeCase("no_opposite",false); }
    function testRFQWins() public { executeCase("rfq_wins",false); }
    function testExpiredRFQFallback() public { executeCase("rfq_expired",false); }
    function testTooCostly() public { executeCase("too_costly",false); }
    function testNoGain() public { executeCase("no_gain",false); }
    function testSameSideFallback() public { executeCase("same_side",false); }
    function testMakerLimitFallback() public { executeCase("maker_limit",false); }
    function testResidualReverts() public { executeCase("residual_revert",true); }
    function testNoFill() public { executeCase("no_fill",false); }
    function testBuyDirect() public { executeCase("buy_direct",false); }
    function testBuyRfq() public { executeCase("buy_rfq",false); }
    function testBuyRollback() public { executeCase("buy_residual_revert",true); }
    function testMakerPartial() public { executeCase("maker_partial",false); }
    function testMakerFullConstraint() public { executeCase("maker_all_or_none",false); }

    function checkedReject(Case memory c,string memory expected) private {
        string memory balances=wallets(); bytes32 h=sut.digest(c.a); bytes32 b=sut.digest(c.b);
        uint256 fa=sut.filled(h); uint256 fb=sut.filled(b);
        (bool ok,bytes memory reason)=invoke(c);
        require(!ok && keccak256(reason)==keccak256(abi.encodeWithSignature("Error(string)",expected)), "rejection reason");
        require(keccak256(bytes(balances))==keccak256(bytes(wallets())) && fa==sut.filled(h) && fb==sut.filled(b),"rollback");
    }
    function testCancel() public { Case memory c=load("direct"); vm.prank(B);sut.cancel(2);checkedReject(c,"cancelled"); }
    function testExpiredSignature() public { Case memory c=load("rfq_wins");vm.warp(block.timestamp+301);checkedReject(c,"expired"); }
    function testWrongSigner() public { Case memory c=load("direct");c.sb=sign(103,c.b);checkedReject(c,"signature"); }
    function testRevoked() public { Case memory c=load("direct");vm.prank(B);u.approve(address(sut),0);checkedReject(c,"allowance"); }
    function testBalance() public { Case memory c=load("direct");vm.prank(B);u.approve(B,2000e6);vm.prank(B);u.transferFrom(B,F,2000e6);checkedReject(c,"inventory"); }
    function testReplay() public { Case memory c=load("direct");(bool ok,)=invoke(c);require(ok);checkedReject(c,"spent"); }
    function testCompetingPartial() public { Case memory c=load("maker_partial");(bool ok,)=invoke(c);require(ok);c.a.nonce++;c.sa=sign(101,c.a);checkedReject(c,"spent"); }
    function testPaused() public { Case memory c=load("direct");sut.setPaused(true);checkedReject(c,"inactive"); }
    function testMakerPriceBound() public { Case memory c=load("direct");c.path.payment=604e6;checkedReject(c,"max spend"); }
    function testMakerSide() public { Case memory c=load("direct");c.b.sell=true;c.sb=sign(102,c.b);checkedReject(c,"opposite"); }
    function testTakerMinEnforced() public { Case memory c=load("direct");c.a.limit=995e6;c.sa=sign(101,c.a);checkedReject(c,"min proceeds"); }
    function testTakerMaxEnforced() public { Case memory c=load("buy_direct");c.a.limit=1005e6;c.sa=sign(101,c.a);checkedReject(c,"max spend"); }
    function testRFQBoundRecipient() public { Case memory c=load("rfq_wins");c.b.counterparty=B;c.sb=sign(103,c.b);checkedReject(c,"recipient binding"); }
    function testWrongDomain() public { Case memory c=load("direct");vm.chainId(177);checkedReject(c,"signature"); }
    function testExpiredFirmOnly() public { Case memory c=load("rfq_wins");c.b.deadline=block.timestamp-1;c.sb=sign(103,c.b);checkedReject(c,"expired"); }
}
