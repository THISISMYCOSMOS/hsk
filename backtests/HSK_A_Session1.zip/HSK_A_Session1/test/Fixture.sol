// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;
import "../src/SessionSettlement.sol";

contract Token is IToken {
    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;
    uint8 public immutable decimals;
    constructor(uint8 d) { decimals=d; }
    function mint(address to, uint256 n) external { balanceOf[to]+=n; }
    function approve(address spender, uint256 n) external { allowance[msg.sender][spender]=n; }
    function transferFrom(address from,address to,uint256 n) external returns(bool) {
        require(allowance[from][msg.sender]>=n, "allowance");
        require(balanceOf[from]>=n, "inventory");
        allowance[from][msg.sender]-=n;
        balanceOf[from]-=n;
        balanceOf[to]+=n;
        return true;
    }
}
contract FixedBook is IBook {
    mapping(bool => mapping(uint256 => uint256)) public prices;
    function set(bool sell,uint256 qty,uint256 usd) external { prices[sell][qty]=usd; }
    function quote(bool sell,uint256 qty) external view returns(uint256) {
        uint256 usd=prices[sell][qty];
        require(usd!=0,"unquoted lot");
        return usd;
    }
}
interface Vm {
    function addr(uint256) external returns(address);
    function sign(uint256,bytes32) external returns(uint8,bytes32,bytes32);
    function prank(address) external;
    function warp(uint256) external;
    function roll(uint256) external;
    function chainId(uint256) external;
    function readFile(string calldata) external view returns(string memory);
    function parseJsonString(string calldata,string calldata) external pure returns(string memory);
    function parseJsonUint(string calldata,string calldata) external pure returns(uint256);
    function parseJsonBool(string calldata,string calldata) external pure returns(bool);
    function parseUint(string calldata) external pure returns(uint256);
    function toString(uint256) external pure returns(string memory);
    function toString(address) external pure returns(string memory);
    function toString(bytes32) external pure returns(string memory);
    function toString(bytes calldata) external pure returns(string memory);
    function writeFile(string calldata,string calldata) external;
    struct Log { bytes32[] topics; bytes data; address emitter; }
    function recordLogs() external;
    function getRecordedLogs() external returns(Log[] memory);
}
