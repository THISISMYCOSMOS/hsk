# 출처·공식 자료와 적용 범위

| 출처 | 이번 세션이 확인한 것 | 근거 파일·한계 |
|---|---|---|
| 팀 원본 HSK_instant_routes.zip | README·replay.py 확인 후 사본 실행, 결과 9,150행 바이트 동일 | raw/ 원본, data/summary.json의 멤버별 SHA-256 |
| 팀 보관 HSKSwap_mainnet_handoff.zip | rpc_week.json 원시 로그의 부호 있는 수량·가격·활성 유동성·틱·식별자를 656건 대조. contracts.json, snapshot.py로 보관 Quoter 호출 해석 | 보관 출처의 SHA-256은 data/summary.json. 원시 영수증 전체는 대표 사례 파일에 없음 |
| HSK Chain 토큰·네트워크 공식 문서 | WHSK·USDT 주소, 메인넷 177·RPC를 대조. scripts/collect.py에서 주소를 사용 | 이번 새 호출은 HTTP 403. 성공한 eth_call 증거는 별도 과거 블록 data/archived_quoter.json |
| HSKSwap UI 및 Blockscout | 같은 시점 UI 순액·경로·전체 가스를 얻지 못함. 단일 풀 Quoter와 구분 | raw/access.json 및 raw/live_probe.json. 대체 공개 RPC도 이 환경에서 403. 이는 외부 서비스 전반의 장애를 뜻하지 않음 |
| Angeris·Chitra·Evans·Boyd (2022) | 경로 사용 고정비를 포함하면 최적 경로 문제가 달라진다는 이론적 근거 | HSK에서 얻는 실제 절감액은 별도 실측 필요 |

[팀 원본](https://chatgpt.com/library?file_id=libfile_8afa5cc9db608191b6757a1f9d888278&account_id=personal) · [팀 메인넷 보관본](https://chatgpt.com/library?file_id=libfile_19cd952fa6a48191a1a28673811aabc2&account_id=personal) · [대표 매도 TX](https://hsk.blockscout.com/tx/0x0ef38234e28a24b668bd147ed168e892997bfe8253ee76164a76d8f8b32162e2) · [공식 네트워크](https://docs.hskchain.net/docs/Build-on-HashKey-Chain/network-info) · [공식 토큰](https://docs.hskchain.net/docs/Build-on-HashKey-Chain/Token-Contracts) · [HSKSwap](https://app.hskswap.com/?lng=en-US) · [논문](https://arxiv.org/abs/2204.05238)

### 사용 가능한 대안

| 후보 | 접근·동일 조건 | 경로·시각 | 비용·실행성·근거 |
|---|---|---|---|
| HSKSwap 기본 UI | 동일 체인·쌍 대상, 당시 같은 수량의 응답 미보관 | 직접/다중 경로와 유효시각 null | 기준선 1순위. 총비용·실행성 null, UI 조회 기록 raw/access.json |
| 직접 QuoterV2 | 공개 읽기, 보관 상태로 같은 쌍 조회 | 단일 풀, 블록에 고정. 공통 실측 주문과 다른 시점은 합산 금지 | 수수료·충격 반영, 정산 가스·실제 체결 미측정. data/archived_quoter.json |
| 기존 집계기·직접 OTC/RFQ | 사용자가 접근할 수 있는 동일 체인·쌍·수량 미확인 | 유효 확정가·유효시간·경로 null | 실제 비교 가능 표본 0. 공급자의 비공개 원가 null |
| 대기 지정가 | B가 실제로 기다릴 수 있는지 인터뷰 필요 | 체결시각·체결보장 null | 즉시 시장매수 대비 절약 가설만 가능 |

### Track 1 개발 방향과 증거

주최 측은 아래 여섯 개발 방향을 제시한다. HSP 의무는 결제 트랙에 적용된다. 공식 권장 제품·프레임워크 활용은 가산점 가능 항목이다. 데모 발표팀은 메인넷 컨트랙트 배포가 필요하다. 제출 시각은 12월 3일 13:00 KST, 서울 데모데이는 12월 5일이다. 현장 참석 가능 여부는 팀장 미확인이다. [주최 측 공지](https://luma.com/mwn8lt3q) · [제출 페이지](https://dorahacks.io/hackathon/hskchainseoul/detail)

| 방향 | 대응 기능·검증 | 현재 증거 |
|---|---|---|
| 시장·온체인 관측 | 같은 블록 수량과 이벤트 순서, 도착시 호가 기록 | raw/block_events.json, scripts/collect.py. 현재 공개 RPC 조회 미완료 |
| AI 신호 | 포함 후 순개선과 사용자 한도 동시 달성 평가 | handoff/risk.json. 적합 가능한 실제 라벨 없음 |
| 차익·스프레드 | 동일 주문의 거래자별 절감 비교. 왕복 차익은 별도 측정 | handoff/test_vectors.json. 왕복 수익 미측정 |
| 자동 주문·포지션 | 대상 경로와 사유를 A에 인계, A가 서명 상태와 한도 검증 | data/candidates.csv. B 세션 메인넷 제품 체결 없음 |
| 손절·위험 | 불리한 재고 변화 스트레스, 한도 미달 거부 | 기존 LP 후보 0건 채택, 실재고 손절 결과 미측정 |
| 대화형 거래 현황·손익 | A가 수량·비용·보류 이유를 표시할 수 있는 입력과 사례 | market_input.json과 test_vectors.json. B가 화면을 빌드한 범위는 없음 |

| 공식 리소스 | 채택·호출 | 사용자 결과 |
|---|---|---|
| HashFans 개발 자료 | 개발 문서 탐색 경로로 확인. SDK 통합·호출 증거 없음 | 추가점수 미판정 |
| HSK Chain 토큰 문서·RPC | collect.py에 공식 자산 주소와 메인넷 ID 반영. 보관본 대조 및 새 RPC 시도 | 잘못된 체인 거부 테스트 통과, 새 메인넷 견적 공백 기록 |
| Chainlink CCIP | 이번 주문은 같은 체인에서 종료. 호출 없음 | 크로스체인 경로 해당 없음 |
| HSP API·Agentic Payment Guide | Track 1. 별도 결제 요구 미확인, 호출 없음 | 결제 통합 해당 없음 |
| Telegram | “기본 UI의 quote API·블록 고정·gas 포함 여부를 확인할 공식 자료는?”이라는 질문 준비. 발송 없음 | 운영자 답변 미수신 |

권장 여부와 자료 목록의 출처는 위 행사 공지다. 리소스 목록 등재 자체로 제품 사용 점수를 인정받았다고 계산하지 않는다. [HashFans](https://hashfans.io/)
