# A/B 인계 규격 1.0

| 파일·필드 | 단위·의미 | 허용 용도 |
|---|---|---|
| market_input의 schema_version / run_id / order_id | 규격, 데이터 생성 회차, 사례 식별자 | A 결정·후속 결과에 그대로 복사 |
| chain_id / block_number / block_hash / tx_hash / tx_index / log_index | 메인넷 177, 정본 확인과 실행 순서. 기본 키는 체인+tx hash+log index | tx hash 단독 병합 금지. 동일 블록은 tx와 log 순서 사용 |
| block_time_utc / observed_at_utc / available_at_utc | 블록 시각 / 수집기 관측 시각 / 주문 판단에 사용할 수 있게 된 시각 | 시간대가 있는 ISO 8601. 재생에서 뒷 두 필드는 null |
| token_in, token_out, amount_raw | 주소·decimals 사전, 입력 토큰 최소 단위 문자열 | WHSK 18, USDT 6. 매수·매도에서 입력 자산이 바뀜 |
| side / kind / user_order_kind | 재생의 방향과 수량 고정 방식 / 실제 주문 방식 | 재구성 exact input과 서명 원주문의 exact input 또는 output을 구별 |
| limit_raw / partial_allowed / expiry | 최소 수령 또는 최대 지출 / 부분 허용 / 만료시각 | 없으면 실행할 수 없음 |
| quote_id / source / quote_origin / firm / available_qty_raw | 후보 식별·출처, 생성 주체, 확약 여부, 사용 가능 수량 | firm null은 미측정. 단일 풀 상태 조회의 firm=false와 구분 |
| benchmark / payer / settlement_gas_USDT | 경로와 비용 차감 단계, 비용 부담자, 정산 가스 환산액 | 기본 UI·기존 최선과 단일 풀 분리. 추정·영수증·가상비용 분리 |
| evidence_mode | archived_mainnet_read=팀 보관 체인 조회, historical_replay=과거 재생, hypothetical=가상. local_fork 및 mainnet_execution은 첫 세션에 해당 없음 | 기술·수요·실현손익을 각각 집계 |
| pre_state_proxy / null_reasons | 사전 대용 상태의 출처 / 누락 사유 | 실제 주문 시각으로 소급하지 않음 |
| population의 notional_USDT / candidates의 taker_out_USDT_equiv | 실제 풀의 USDT 측 절댓값 / 직전 현물가 기준 입력자 수령 환산액 | CSV 빈 칸은 해당 없음·미측정. 탈락 사유나 원인 열과 함께 사용 |
| outcome.json / risk.json | 결과 대조와 모델 차단 이유 | outcome과 미래 tick은 입력에서 제외 |
| test_vectors의 *_whsk_raw / 나머지 통화 *_raw | WHSK / USDT의 정수 문자열 | A는 expected_output과 수량·통화·선택·탈락 사유를 대조 |

**A → B.** 같은 run_id와 order_id에 candidates[]를 연결한다. 후보별 경로·투입·수령·사용자 기준선·비용 부담자·탈락 이유·AI 사용 전후 선택을 남긴다. 접수·제출·포함·확정 시각과 block/hash, tx hash, status, actual gas 및 수수료 환산 가격의 시각·출처, 재시도 연결 ID, 사용자별 최종 잔고 변화를 별도로 보낸다. 실제 집행 전에는 이 값들을 null로 둔다. 선택하지 않은 경로는 당시 견적 또는 포크 결과로 표시한다.
