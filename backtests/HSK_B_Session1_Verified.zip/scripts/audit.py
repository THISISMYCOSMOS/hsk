"""Replay a fresh copy, then compare the archive, logs and per-swap candidates."""
import csv
import hashlib
import io
import json
import subprocess
import sys
import tempfile
from collections import Counter, defaultdict
from decimal import Decimal as D
from pathlib import Path
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data'
HAND = ROOT / 'handoff'
RUN = 'HSK-B1-20261126'
def dump(path, body):
    path.write_text(json.dumps(body, indent=2, ensure_ascii=False, allow_nan=False)+'\n')
def table(name, rows):
    with (DATA/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=rows[0]); w.writeheader(); w.writerows(rows)
def digest(b):
    return hashlib.sha256(b).hexdigest()
def signed(n):
    return n-(1<<256) if n >= 1<<255 else n
def words(s):
    return [int(s[k:k+64],16) for k in range(2,len(s),64)]
def ceildiv(n,d):
    return (n+d-1)//d

def main():
    src=ROOT/'raw/HSK_instant_routes.zip'
    supplement=ROOT/'raw/HSKSwap_mainnet_handoff.zip'
    assert digest(src.read_bytes())=='7e9a59d4773a3d535ad576b4ecc55c2c1174ff75217c3287516f7e222e79c825'
    assert digest(supplement.read_bytes())=='4d165a283ff0b16763082da05c0a87542e973364f7b9275931cc19182051efdd'
    with ZipFile(src) as z, tempfile.TemporaryDirectory() as tmp:
        z.extractall(tmp)
        out=subprocess.check_output([sys.executable,'replay.py'],cwd=tmp)
        (DATA/'replay.stdout').write_bytes(out)
        gen=Path(tmp,'results.csv').read_bytes()
        assert gen==z.read('results.csv')
        source_hashes={n:digest(z.read(n)) for n in z.namelist()}
        results=list(csv.DictReader(io.StringIO(gen.decode())))
        rows=[r for r in csv.DictReader(io.StringIO(z.read('swaps.csv').decode())) if r['base']=='WHSK']
    with ZipFile(supplement) as z:
        reg=json.loads(z.read('contracts.json'))
        rawlogs=json.loads(z.read('rpc_week.json'))
    pool=reg['contracts']['WHSK_pool']
    events={(e['transactionHash'],int(e['logIndex'],16)):e for e in rawlogs if e['address']==pool}
    assert len(events)==len(rows)==656 and len({r['tx_hash'] for r in rows})==656
    lookup={(r['tx'],r['scenario'],D(r['cost'])):r for r in results}
    exclusions=[]; choices=[]; tag=Counter(); selected=[]; detail=defaultdict(list)
    prev=None
    for r in rows:
        tx=r['tx_hash']; e=events[tx,int(r['log_index'])]
        a,b,p,l,t=words(e['data'])
        assert [signed(a),signed(b),p,l,signed(t)]==[int(r[k]) for k in ('amount0_raw','amount1_raw','sqrt_price_x96_after','active_liquidity_after','tick_after')]
        assert not e['removed'] and e['blockHash']==r['block_hash'] and int(e['blockNumber'],16)==int(r['block'])
        if prev:
            assert (int(prev['block']),int(prev['log_index']))<(int(r['block']),int(r['log_index']))
        reason='accepted'; err=None
        band_change=liquidity_change=None
        if prev is None: reason='no_previous_swap'
        else:
            band_change=int(prev['tick_after'])//60!=signed(t)//60
            liquidity_change=int(prev['active_liquidity_after'])!=l
            if band_change or liquidity_change:
                reason='band_and_liquidity' if band_change and liquidity_change else ('band' if band_change else 'liquidity')
            else:
                s=int(prev['sqrt_price_x96_after'])/2**96
                spot=s*s*1e12; depth=l*s/1e6
                sell=signed(a)>0
                size=float(r['pool_delta_base'])*spot if sell else float(r['pool_delta_USDT'])
                received=-float(r['pool_delta_USDT']) if sell else -float(r['pool_delta_base'])*spot
                def amm(x,m=1): return x*.997/(1+x*.997/(depth*m))
                err=abs(amm(size)-received)
                if err>1.1e-6: reason='output_error'
        tag[reason]+=1; detail[reason].append(D(r['notional_USDT']))
        exclusions.append(dict(block=r['block'],tx=tx,log_index=r['log_index'],side=r['direction'],notional_USDT=r['notional_USDT'],reason=reason,band_changed=band_change,active_L_changed=liquidity_change,output_error_USDT=err))
        if reason=='accepted':
            selected.append(r)
            for cost in (0,.01,.05):
                matched=min(50,size)
                opts=[('pool',amm(size),None),('direct' if matched==size else 'direct+pool',matched*.999+amm(size-matched)-cost,None),('RFQ',size*.9985-cost,None)]
                for name,m in [('LP',0),('direct+LP',matched)]:
                    rest=size-m
                    stress=rest*.003/2-(rest if sell else amm(rest,2))*.005/2
                    why='no_remainder' if rest<=0 else ('negative_LP_stress' if stress<0 else None)
                    opts.append((name,m*.999+amm(rest,2)-cost if not why else None,why))
                best=max((o for o in opts if not o[2]),key=lambda o:o[1])
                expected=lookup[tx,'all',D(str(cost))]
                assert best[0]==expected['winner'] and abs(best[1]-amm(size)-float(expected['gain']))<1e-10
                for name,value,why in opts:
                    choices.append(dict(chain_id=177,tx_hash=tx,log_index=r['log_index'],side=r['direction'],cost_USDT=cost,route=name,taker_out_USDT_equiv=value,gain_USDT=None if value is None else value-amm(size),selected=name==best[0],reason=why or ('best' if name==best[0] else 'lower_net_or_tie'),evidence_mode='historical_replay' if name=='pool' else 'hypothetical'))
        prev=r
    table('population.csv',exclusions);table('candidates.csv',choices)
    def group(s,c):
        return [r for r in results if r['scenario']==s and D(r['cost'])==D(c)]
    def gains(s,c):
        return sum(D(r['gain']) for r in group(s,c))
    direct=gains('direct','.01'); all01=gains('all','.01')
    metrics=[('WHSK',656,len(rows)),('evaluated',610,len(selected)),('sell',547,sum(int(r['amount0_raw'])>0 for r in selected)),('buy',63,sum(int(r['amount0_raw'])<0 for r in selected)),('LP_before_cost','0.413673',sum(D(r['raw_LP_gain']) for r in group('all','.01'))),('direct_001','15.084499',direct),('all_001','16.036351',all01),('all_minus_direct','0.951852',all01-direct),('all_005','2.667764',gains('all','.05')),('LP_pool_wins_001',610,sum(r['winner']=='pool' for r in group('LP','.01')))]
    audit=[]
    for name,v,x in metrics:
        got=D(x).quantize(D('0.000001')) if isinstance(v,str) else x
        assert D(got)==D(v)
        audit.append(dict(metric=name,reference=str(v),reproduced=str(got),difference=str(D(got)-D(v)),unrounded=str(x)))
    table('reconciliation.csv',audit)
    dump(DATA/'summary.json',dict(source_sha256=digest(src.read_bytes()),member_sha256=source_hashes,output_byte_equal=True,supplement_sha256=digest(supplement.read_bytes()),raw_swap_log_matches=len(rows),by_reason={k:dict(count=tag[k],abs_USDT_leg=str(sum(v))) for k,v in detail.items()},winners_001=Counter(r['winner'] for r in group('all','.01'))))
    # Same-block order: quote the second sell from the first sell's recorded post-state.
    target=next(r for r in rows if r['tx_hash'].startswith('0x0ef38234'))
    i=rows.index(target); before=rows[i-1]
    pair=[events[r['tx_hash'],int(r['log_index'])] for r in [before,target]]
    assert pair[0]['blockHash']==pair[1]['blockHash']
    dump(ROOT/'raw/block_events.json',pair)
    P=int(before['sqrt_price_x96_after']); L=int(before['active_liquidity_after']); Q=2**96
    amount=int(target['amount0_raw']); net=amount*997000//1000000
    nextP=ceildiv(L*Q*P,L*Q+net*P)
    output=L*(P-nextP)//Q
    observed=-int(target['amount1_raw'])
    assert output==observed and nextP==int(target['sqrt_price_x96_after'])
    missing={'observed_at_utc':'historical collector receipt time unavailable','available_at_utc':'block time does not prove order-time availability','limit_raw':'no signed order','expiry':'no signed order','partial_allowed':'no signed order','firm':'no participant quote','available_qty_raw':'no maker inventory record','default_router_quote':'UI routing not captured at arrival','best_existing_quote':'simultaneous alternatives unavailable','user_order_kind':'Swap log contains deltas only','receipt':'raw full receipt unavailable in archive','settlement_gas_USDT':'no agent settlement or gas conversion','payer':'transaction cost payer for proposed path unknown','signature':'no authorized order','balance_raw':'no maker specified','allowance_raw':'no maker specified','remaining_raw':'no signed order','lp_range':'single active liquidity value does not identify LP ranges','pre_swap_mint_burn':'archive contains Swap logs only'}
    record=dict(schema_version='1.0',run_id=RUN,order_id='replay-'+target['tx_hash']+'-'+target['log_index'],chain_id=177,block_number=int(target['block']),block_hash=target['block_hash'],block_time_utc=target['utc'],tx_hash=target['tx_hash'],tx_index=int(pair[1]['transactionIndex'],16),log_index=int(target['log_index']),side='sell_WHSK',kind='exact_input_reconstruction',token_in={'address':reg['tokens']['WHSK'],'decimals':18},token_out={'address':reg['tokens']['USDT'],'decimals':6},amount_raw=str(amount),quote_id='single_pool_exact_in',source='team archived eth_getLogs + local integer calculation',quote_origin='reconstructed_pool',evidence_mode='historical_replay',fee_pips=3000,benchmark={'route':[pool],'amount_out_raw':str(output),'basis':'single pool before settlement gas'},pre_state_proxy={'event_tx':before['tx_hash'],'tx_index':int(pair[0]['transactionIndex'],16),'log_index':int(before['log_index']),'sqrtPriceX96':str(P),'L':str(L),'tick':int(before['tick_after'])},permitted_use='local regression, single active band only',null_reasons=missing,**dict.fromkeys(missing))
    dump(HAND/'market_input.json',record)
    dump(DATA/'outcome.json',{'order_id':record['order_id'],'block_time_utc':target['utc'],'observed_pool_out_raw':str(observed),'reconstructed_out_raw':str(output),'error_raw':str(output-observed),'post_sqrtPriceX96':str(nextP),'agent_realized_out_raw':None,'source':'raw/block_events.json[1]'})
    vs=words(reg['checks'][pool]['quote_one_USDT_raw'])
    dump(DATA/'archived_quoter.json',dict(block_number=reg['block'],block_hash=reg['block_hash'],block_time_utc=reg['utc'],chain_id=177,method='eth_call',to=reg['contracts']['quoter_v2'],selector='0xc6a5026a',token_in=reg['tokens']['USDT'],token_out=reg['tokens']['WHSK'],amount_in_raw='1000000',fee=3000,sqrtPriceLimitX96='0',raw_response=reg['checks'][pool]['quote_one_USDT_raw'],amount_out_raw=str(vs[0]),quote_gas_estimate=str(vs[3]),source='supplement contracts.json/checks + snapshot.py',evidence_mode='archived_mainnet_read',firm=False))
    print('PASS: 656 decoded logs, archive results byte-identical, 610 decisions x 3 costs, 10 controls, same-block integer quote.')
if __name__=='__main__': main()
