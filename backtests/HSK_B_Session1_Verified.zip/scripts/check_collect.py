"""Offline transport fixture, no test wallet or live observation."""
from collect import capture,W,U
from copy import deepcopy
from pathlib import Path
import json
D=Path(__file__).resolve().parents[1]/'handoff'
bh='0x'+'33'*32
at='2026-11-26T04:00:00+00:00'
expiry='2026-11-26T04:01:00+00:00'
header={'hash':bh,'number':'0x11','timestamp':'0x6a000000'}
def mock(m,p):
    if m=='eth_chainId':return '0xb1'
    if m in ('eth_getBlockByNumber','eth_getBlockByHash'):return header
    if m=='eth_gasPrice':return '0x1'
    if m=='eth_call':
        if p[0]['data'].startswith('0x1698ee82'):return '0x'+format(123,'064x')
        assert p[0]['data'].startswith('0xc6a5026a') and p[1]=='0x11'
        return '0x'+''.join(format(v,'064x') for v in (900000,234,0,75))
    raise ValueError(m)
inp=dict(order_id='fixture-1',chain_id=177,side='sell_WHSK',kind='exact_input',amount_raw=str(10**18),arrival_utc=at,arrival_block_hash=bh,origin='synthetic')
q=dict(order_id=inp['order_id'],chain_id=177,side=inp['side'],kind=inp['kind'],amount_raw=inp['amount_raw'],block_hash=bh,received_at_utc=at,expiry=expiry,source='mock UI',quote_id='mock-ui',amount_out_raw='900000',route=['example'],evidence_ref='mock-ui-response')
maker=dict(origin='team_test',approval_ref='synthetic',signed_order_ref='synthetic',chain_id=177,block_hash=bh,side='buy_WHSK',sell_token=U,buy_token=W,received_at_utc=at,expiry=expiry,remaining_raw='500000',balance_raw='600000',allowance_raw='500000',available_qty_raw='500000',limit_raw='300000000000000000')
inp.update(default_ui=[q],alternative_quotes=[dict(q,source='mock RFQ',received_at_utc=expiry)],approved_test_orders=[maker])
def check():
    rec=capture(inp,mock)
    assert rec['comparable_at_arrival'] and rec['single_pool']['amount_out_raw']=='900000'
    assert rec['two_pool_via_WETH']['legs'][1]['amount_in_raw']=='900000'
    assert rec['alternative_quotes'][0]['exclusion']=='received_after_arrival'
    assert rec['approved_test_orders'][0]['exclusion'] is None and not rec['approved_test_orders'][0]['execution_eligible']
    assert not capture(inp,lambda m,p: '0x1')['comparable_at_arrival']
    assert not capture(inp,lambda m,p:dict(header,hash='orphan') if m=='eth_getBlockByNumber' else mock(m,p))['comparable_at_arrival']
    x=deepcopy(inp);x['default_ui'][0]['expiry']=at
    assert not capture(x,mock)['comparable_at_arrival']
    x=deepcopy(inp);x['approved_test_orders'][0]['allowance_raw']='0'
    assert capture(x,mock)['approved_test_orders'][0]['exclusion']
    (D/'collector_example_SYNTHETIC.json').write_text(json.dumps(inp,indent=2)+'\n')
    print('PASS: block binding, expiry, late quote, funding, wrong chain, reorg.')
if __name__=='__main__':check()
