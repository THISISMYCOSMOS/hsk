import csv
from collections import defaultdict
from decimal import Decimal as D
from pathlib import Path
from statistics import median
from zipfile import ZipFile
from io import TextIOWrapper
from audit import ROOT,table
def main():
    groups=defaultdict(list)
    with ZipFile(ROOT/'raw/HSK_instant_routes.zip') as z, z.open('results.csv') as src:
        for r in csv.DictReader(TextIOWrapper(src)):
            if r['scenario']!='all':continue
            x=D(r['size'])
            band='<5' if x<5 else '5-<50' if x<50 else '>=50'
            for side,size in [(r['side'],band),(r['side'],'all'),('all','all')]:
                groups[r['cost'],side,size].append((x,D(r['gain'])))
    out=[]
    for (cost,side,size),items in groups.items():
        vs=sorted((g for _,g in items),reverse=True);n=sum(x for x,_ in items)
        out.append(dict(cost_USDT=cost,side=side,size_USDT=size,n=len(items),improved=sum(g>0 for g in vs),tied=vs.count(0),negative=sum(g<0 for g in vs),notional_USDT_equiv=n,total_gain_USDT=sum(vs),median_gain_USDT=median(vs),weighted_bps=sum(vs)*10000/n,top10_share=sum(vs[:10])/sum(vs) if sum(vs)>0 else None))
    table('hypothetical_by_side_size.csv',out)
if __name__=='__main__':main()
