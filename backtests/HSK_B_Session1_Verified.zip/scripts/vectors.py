"""Independent arithmetic oracle. Integer USDT has 6 decimals and WHSK has 18."""
import json
from pathlib import Path
from copy import deepcopy
from datetime import datetime
D=Path(__file__).resolve().parents[1]/'handoff'
def solve(inp):
    base,alternative,tail,fee=[int(inp[k]) for k in ('seller_baseline_raw','buyer_baseline_raw','tail_out_raw','seller_extra_cost_raw')]
    total=alternative+tail-fee-base
    price=alternative-(total-total//2)  # odd micro-USDT goes to the buyer
    candidates=[dict(route='default',seller_net_raw=str(base),buyer_spend_raw=None,seller_gain_raw='0',buyer_gain_raw=None,objective_gain_raw='0',payment_raw=None,reason=None)]
    reason=None
    if int(inp['fill_whsk_raw'])+int(inp['tail_whsk_raw'])!=int(inp['input_whsk_raw']): reason='quantity_mismatch'
    elif total<0: reason='negative_combined_savings'
    elif price>int(inp['buyer_max_raw']) or tail+price-fee<int(inp['seller_min_raw']): reason='signed_limit'
    candidates.append(dict(route='direct_plus_pool',seller_net_raw=str(tail+price-fee),buyer_spend_raw=str(price),seller_gain_raw=str(tail+price-fee-base),buyer_gain_raw=str(alternative-price),objective_gain_raw=str(total),payment_raw=str(price),reason=reason))
    rfq=inp['rfq']
    reason='unavailable' if rfq is None else ('expired' if datetime.fromisoformat(rfq['expiry'])<=datetime.fromisoformat(inp['arrival']) else None)
    v=int(rfq['net_raw']) if rfq else None
    if reason is None and v<max(base,int(inp['seller_min_raw'])):reason='below_limit_or_baseline'
    candidates.append(dict(route='full_RFQ',seller_net_raw=str(v) if v is not None else None,buyer_spend_raw=None,seller_gain_raw=str(v-base) if v is not None else None,buyer_gain_raw=None,objective_gain_raw=str(v-base) if v is not None else None,payment_raw=None,reason=reason))
    if base<int(inp['seller_min_raw']): candidates[0]['reason']='signed_limit'
    valid=[r for r in candidates if not r['reason']]
    winner=max(valid,key=lambda r:(int(r['objective_gain_raw']),int(r['seller_gain_raw']),r['route']=='default')) if valid else None
    for r in candidates:
        if not r['reason']:r['reason']='selected' if r is winner else 'lower_gain_or_tiebreak'
    return dict(selected=winner['route'] if winner else 'unfilled',candidates=candidates)
def main():
    inp=dict(input_whsk_raw=str(1000*10**18),fill_whsk_raw=str(600*10**18),tail_whsk_raw=str(400*10**18),seller_baseline_raw='990000000',buyer_baseline_raw='603000000',tail_out_raw='397000000',seller_extra_cost_raw='2000000',seller_min_raw='990000000',buyer_max_raw='603000000',arrival='2026-11-26T04:00:00+00:00',rfq=dict(net_raw='1001000000',expiry='2026-11-26T04:01:00+00:00'))
    cases=[
        ('rfq_present',{},'full_RFQ'),('rfq_absent',{'rfq':None},'direct_plus_pool'),
        ('rfq_expired',{'rfq':dict(inp['rfq'],expiry=inp['arrival'])},'direct_plus_pool'),
        ('cost_exceeds_spread',{'rfq':None,'seller_extra_cost_raw':'12000000'},'default'),
        ('cost_equals_spread',{'rfq':None,'seller_extra_cost_raw':'10000000'},'default'),
        ('all_below_limit',{'seller_min_raw':'1002000000'},'unfilled'),
        ('odd_micro',{'rfq':None,'seller_extra_cost_raw':'2000001'},'direct_plus_pool')]
    bundle=[]
    for name,override,expected in cases:
        x=deepcopy(inp);x.update(override); y=solve(x);assert y['selected']==expected
        a=y['candidates'][1]
        if name in ('rfq_present','rfq_absent','rfq_expired'):
            assert (a['payment_raw'],a['seller_net_raw'],a['buyer_spend_raw'],a['seller_gain_raw'],a['buyer_gain_raw'])==('599000000','994000000','599000000','4000000','4000000')
        if name=='rfq_present': assert y['candidates'][2]['seller_gain_raw']=='11000000'
        if name=='odd_micro':assert (a['seller_gain_raw'],a['buyer_gain_raw'])==('3999999','4000000')
        bundle.append({'case':name,'input':x,'expected_output':y})
    path=D/'test_vectors.json'
    body=dict(schema_version='1.0',evidence_mode='hypothetical',quote_origin='synthetic',side='sell_WHSK',kind='exact_input',units={'whsk_raw':18,'other_monetary_raw_USDT':6},objective='combined_comparable_user_saving',cost_payer='A',assumptions='test-only valid funded orders except explicit overrides; RFQ net includes all taker costs; no RFQ-maker P&L',cases=bundle)
    if path.exists(): assert json.loads(path.read_text())==body
    else:path.write_text(json.dumps(body,indent=2)+'\n')
    print('PASS: 7 economic fixtures.')
if __name__=='__main__':main()
