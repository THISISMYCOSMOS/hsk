"""B's independent integer settlement calculation for the S1-direct fixture."""
from pathlib import Path
import csv
import json

root = Path(__file__).resolve().parents[1]
source = root / 'raw' / 'A'
book = json.loads((source / 'book.json').read_text())
sell = book['sell']
full, rest, baseline = (int(sell[k]) for k in ('dex_full_raw', 'dex_rest_raw', 'other_baseline_raw'))
fee = int(book['fee_raw'])
amount, lot = (int(book[k]) for k in ('amount_raw', 'opposite_lot_raw'))
gain = baseline + rest - fee - full
payment = full + gain // 2 - rest + fee
net = payment + rest - fee
assert 0 < lot <= min(amount, int(book['opposite_capacity_raw']))
assert net >= int(sell['limit_raw']) and payment <= int(sell['other_limit_raw'])
balances = {'A': (-amount, net), 'B': (lot, -payment), 'DEX': (amount-lot, -rest),
            'fee_collector': (0, fee), 'RFQ_maker': (0, 0)}
expected = {'decision.route':'direct+dex', 'decision.payment_raw':str(payment),
            'decision.rule_selection':'direct+dex', 'decision.ai_selection':None,
            'execution.filled_A_raw':str(amount), 'execution.filled_other_raw':str(lot),
            'actual_service_fee_usdt_raw':str(fee), 'execution.status':'settled',
            'decision.rfq_status':'absent', 'tx_hash':None, 'gas_used_raw':None}
for field, value in dict(route=2, whsk_raw=str(amount), direct_whsk_raw=str(lot),
                         direct_usdt_raw=str(payment),book_usdt_raw=str(rest),fee_raw=str(fee)).items():
    expected['execution.event.' + field] = value
# S1-direct has no registered whole-order RFQ. The static book also supplies
# a price for a different scenario, where the RFQ is present.
for route, eligible in [('dex',True),('direct+dex',True),('rfq',False),('no_fill',True)]:
    expected[f'candidates.{route}.eligible'] = eligible
expected.update({'candidates.rfq.exclusion':'rfq_absent','quotes.RFQ_all.registered':False,
                 'quotes.RFQ_all.available_qty_raw':'0','quotes.RFQ_all.cash_raw':None})
for field, value in dict(a_net_usdt_raw=net, b_usdt_raw=payment, a_gain_raw=net-full,
                         b_gain_raw=baseline-payment,total_gain_raw=gain).items():
    expected['candidates.direct+dex.'+field] = str(value)
for i, token in enumerate(('WHSK','USDT')):
    assert sum(pair[i] for pair in balances.values()) == 0
    for account, pair in balances.items():
        for key in ('wallet_delta_raw','delta_from_balances'):
            expected[f'{key}.{account}.{token}'] = str(pair[i])
(root/'handoff'/'S1_direct_expected.json').write_text(json.dumps(expected,indent=2)+'\n')

actual = json.loads((source/'first_order.json').read_text())
actual['candidates'] = {c['route']:c for c in actual['decision']['candidates']}
actual['quotes'] = {q['source']:q for q in actual['quote_book']}
execution = actual['execution']
actual['delta_from_balances'] = {
    a:{t:str(int(end)-int(execution['before'][a][t])) for t,end in cells.items()}
    for a,cells in execution['after'].items()}
with (root/'data'/'S1_direct_comparison.csv').open('w',newline='') as f:
    writer = csv.writer(f)
    writer.writerow(['order_id','field','B_expected_json','A_actual_json','match'])
    errors = []
    for key,value in expected.items():
        observed = actual
        for part in key.split('.'):
            observed = observed[part]
        match = json.dumps(value) == json.dumps(observed)
        writer.writerow(['S1-direct',key,json.dumps(value),json.dumps(observed),match])
        if not match:
            errors.append(key)
if errors:
    raise ValueError(errors)
print(f'PASS: {len(expected)} S1-direct comparisons including all account deltas.')
