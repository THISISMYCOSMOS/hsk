"""One read-only capture per arrival. Invoke once per order from the intake adapter."""
import argparse
import json
import os
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

W='0xb210d2120d57b758ee163cffb43e73728c471cf1'
U='0xf1b50ed67a9e2cc94ad3c477779e2d4cbfff9029'
Q='0x603f70466fddbe3f238220b9a74fff419a2bbfdd'
def utc():
    return datetime.now(timezone.utc).isoformat()
def instant(s):
    dt=datetime.fromisoformat(s.replace('Z','+00:00'))
    if dt.utcoffset() is None:raise ValueError('UTC timestamp requires offset')
    return dt
def rpc(method,params):
    url=os.environ.get('HSK_RPC','https://mainnet.hsk.xyz')
    req=urllib.request.Request(url,data=json.dumps(dict(jsonrpc='2.0',id=1,method=method,params=params)).encode(),headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=10) as res:body=json.load(res)
    if body.get('error') or body.get('result') is None: raise ValueError(str(body.get('error','missing RPC result')))
    return body['result']
def word(n):
    return format(int(n,16) if isinstance(n,str) else n,'064x')
def positive(s):
    return isinstance(s,str) and s.isascii() and s.isdigit() and 0<int(s)<2**256
F='0x972ca9d1662f5e029cd18327d29026532e84c742'
E='0xefd4bc9afd210517803f293ababd701caeecdfd0'
def single(call,a,b,amount,block):
    request={'to':Q,'data':'0xc6a5026a'+''.join(word(x) for x in (a,b,amount,3000,0))}
    raw=call('eth_call',[request,block['number']])
    if len(raw)!=258 or not raw.startswith('0x'):raise ValueError('invalid QuoterV2 response')
    return dict(request=request,response_raw=raw,amount_out_raw=str(int(raw[2:66],16)),fee=3000,source='single_pool_QuoterV2',firm=False,gas_estimate_quoter_only=str(int(raw[-64:],16)),received_at_utc=utc())
def route_read(call,inp,block,via_eth=False):
    a,b=(W,U) if inp['side']=='sell_WHSK' else (U,W)
    qty=int(inp['amount_raw'])
    if not via_eth:return single(call,a,b,qty,block)
    legs=[]
    for start,end in ((a,E),(E,b)):
        factory_data='0x1698ee82'+word(start)+word(end)+word(3000)
        pool=call('eth_call',[{'to':F,'data':factory_data},block['number']])
        if len(pool)!=66 or int(pool,16)==0:raise ValueError('no verified 0.30% pool for '+start+' -> '+end)
        leg=single(call,start,end,qty,block)
        leg.update(pool='0x'+pool[-40:],token_in=start,token_out=end,amount_in_raw=str(qty))
        legs.append(leg);qty=int(leg['amount_out_raw'])
    return dict(source='two_distinct_pool_quotes',route=[a,E,b],legs=legs,amount_out_raw=str(qty),firm=False,received_at_utc=utc())
def inspect_entry(x,inp,bh,at,category):
    if x.get('chain_id')!=177 or x.get('block_hash')!=bh:return 'unanchored_or_different_block'
    if x.get('order_id')!=inp['order_id'] or x.get('side')!=inp['side'] or x.get('kind')!='exact_input' or x.get('amount_raw')!=inp['amount_raw']:return 'different_order'
    try:
        if instant(x['received_at_utc'])>at:return 'received_after_arrival'
        if instant(x['expiry'])<=at:return 'expired_at_arrival'
    except (KeyError,ValueError,TypeError):return 'missing_or_invalid_time'
    if not x.get('source') or not x.get('quote_id') or not positive(x.get('amount_out_raw')):return 'missing_quote_fields'
    if category=='default_ui' and (not x.get('route') or not x.get('evidence_ref')):return 'default_route_evidence_missing'
    return None
def capture(inp,call=rpc):
    at=instant(inp['arrival_utc'])
    if inp.get('chain_id')!=177 or inp.get('kind')!='exact_input' or inp.get('side') not in ('sell_WHSK','buy_WHSK') or not positive(inp.get('amount_raw')):raise ValueError('invalid order scope/amount')
    rec=dict(schema_version='1.0',run_id=str(uuid4()),order_id=inp['order_id'],order=inp,started_at_utc=utc(),chain_id=177,block_number=None,block_hash=None,default_ui=None,alternative_quotes=[],approved_test_orders=[],single_pool=None,agent_receipt=None,null_reasons={},comparable_at_arrival=False)
    why=rec['null_reasons']
    try:
        if int(call('eth_chainId',[]),16)!=177:raise ValueError('wrong chain')
        if inp.get('arrival_block_hash'):
            block=call('eth_getBlockByHash',[inp['arrival_block_hash'],False])
            if block['hash']!=inp['arrival_block_hash']:raise ValueError('block hash mismatch')
        else:block=call('eth_getBlockByNumber',['latest',False])
        rec.update(block_hash=block['hash'],block_number=int(block['number'],16))
        anchored=bool(inp.get('arrival_block_hash')) and int(block['timestamp'],16)<=at.timestamp()
        # Only read previously buffered external quotes. Never poll a maker after cutoff.
        for category,dest in [('default_ui','default_ui'),('alternative_quotes','alternative_quotes')]:
            for x in inp.get(category,[]):
                issue=inspect_entry(x,inp,block['hash'],at,category)
                item=dict(record=x,exclusion=issue,firm_verified=None)
                if category=='default_ui':
                    if rec[dest] is not None:raise ValueError('ambiguous default UI capture')
                    rec[dest]=item
                else:rec[dest].append(item)
        for x in inp.get('approved_test_orders',[]):
            reason=None
            try:
                if x.get('origin')!='team_test' or not x.get('approval_ref') or not x.get('signed_order_ref'):reason='missing_approval_or_signed_ref'
                elif x.get('chain_id')!=177 or x.get('block_hash')!=block['hash'] or x.get('side')!=('buy_WHSK' if inp['side']=='sell_WHSK' else 'sell_WHSK'):reason='pair_direction_or_anchor'
                elif instant(x['received_at_utc'])>at or instant(x['expiry'])<=at:reason='late_or_expired'
                elif x.get('sell_token','').lower()!=(U if inp['side']=='sell_WHSK' else W) or x.get('buy_token','').lower()!=(W if inp['side']=='sell_WHSK' else U):reason='token_mismatch'
                elif not all(positive(x.get(k)) for k in ('remaining_raw','balance_raw','allowance_raw','available_qty_raw','limit_raw')):reason='missing_funding_or_terms'
                elif int(x['available_qty_raw'])>min(int(x[k]) for k in ('remaining_raw','balance_raw','allowance_raw')):reason='unfunded_quantity'
            except (KeyError,ValueError,TypeError):reason='invalid_order_evidence'
            rec['approved_test_orders'].append(dict(record=x,exclusion=reason,firm_verified=None,execution_eligible=False))
        with ThreadPoolExecutor(max_workers=3) as workers:
            q=workers.submit(route_read,call,inp,block)
            alt=workers.submit(route_read,call,inp,block,True)
            gas=workers.submit(call,'eth_gasPrice',[])
            for k,f in [('single_pool',q),('two_pool_via_WETH',alt),('current_gas_price_wei',gas)]:
                try:
                    v=f.result();rec[k]=str(int(v,16)) if k=='current_gas_price_wei' else v
                except Exception as e:rec[k]=None;why[k]=str(e)
        if call('eth_getBlockByNumber',[block['number'],False])['hash']!=block['hash']:raise ValueError('block reorg')
        if not anchored:why['arrival_anchor']='arrival block hash unavailable or block later than order'
        rec['comparable_at_arrival']=bool(anchored and rec['default_ui'] and rec['default_ui']['exclusion'] is None and rec['single_pool'])
        rec['status']='captured' if rec['single_pool'] else 'partial'
    except Exception as e:why['chain_capture']=str(e);rec['status']='incomplete';rec['comparable_at_arrival']=False
    for k in ('two_pool_via_WETH','single_pool','default_ui','alternative_quotes','approved_test_orders','agent_receipt'):
        if not rec.get(k):rec.setdefault(k,None);why.setdefault(k,'no matching source material captured')
    rec['ended_at_utc']=utc()
    return rec
def main():
    p=argparse.ArgumentParser();p.add_argument('envelope',nargs='?');p.add_argument('--out',required=True);args=p.parse_args()
    inp=json.loads(Path(args.envelope).read_text()) if args.envelope else dict(order_id='probe-'+str(uuid4()),chain_id=177,side='buy_WHSK',kind='exact_input',amount_raw='1000000',arrival_utc=utc(),origin='read_only_probe')
    record=capture(inp)
    with Path(args.out).open('x') as f:json.dump(record,f,ensure_ascii=False,indent=2)
    print(record['status'],args.out)
if __name__=='__main__':main()
