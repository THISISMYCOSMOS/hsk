from pathlib import Path
import subprocess
import sys
root=Path(__file__).resolve().parent
for script in ('audit.py','vectors.py','breakdown.py','check_collect.py','check_first_order.py'):
    subprocess.run([sys.executable,'-B',str(root/'scripts'/script)],cwd=root,check=True)
