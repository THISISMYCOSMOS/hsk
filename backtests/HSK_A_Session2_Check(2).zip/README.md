2026-11-26 · 블록 30592078 보관 상태로 재구성한 단일 풀 견적 + 모의 정산. 실제 포크·가스비·참가자 주문 미측정. direct / no_gain / too_costly의 추가 비용은 각각 0, 0.309994, 2 USDT.
재현: HSK_A_Session1 복사본에 fixtures/plans의 세 파일을 같은 경로로 복사한 다음 아래 명령을 실행.

    forge test --match-test "test(Direct|NoGain|TooCostly)\(" 

실행 후 handoff/evm_*.json 중 해당 세 사례의 before, after, event를 확인. run.sh는 첫 세션 입력으로 계획을 재생성하므로 이 검산에는 위 명령을 사용.
